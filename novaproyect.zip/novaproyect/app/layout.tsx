import type { Metadata } from "next";
import "./globals.css";
import { brand } from "@/lib/mock-data";

export const metadata: Metadata = {
  title: `${brand.name} | Diseño web y gráfico`,
  description:
    "Creamos páginas web y diseños gráficos para ayudar a tu negocio a tener una presencia digital profesional.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
