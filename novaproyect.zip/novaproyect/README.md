# NovaProyect

Landing page comercial para captar clientes de diseño web y diseño gráfico mediante WhatsApp.

## Requisitos

- Node.js 20.9 o posterior
- npm

## Ejecutar en desarrollo

```bash
npm install
npm run dev
```

Abre http://localhost:3000.

## Comprobar la versión de producción

```bash
npm run build
npm run start
```

## Personalizar datos

Edita `lib/mock-data.ts` para actualizar el número de WhatsApp, mensaje, enlaces sociales, servicios y proyectos demostrativos. Los enlaces sociales están vacíos deliberadamente hasta que se proporcionen las URL oficiales.

## Notas

- Los proyectos del portafolio están identificados como demostraciones conceptuales.
- No hay backend, formularios, endpoints ni almacenamiento de datos.
- El precio se consulta directamente por WhatsApp.
- La aplicación no incorpora un modo claro/oscuro alternativo.
